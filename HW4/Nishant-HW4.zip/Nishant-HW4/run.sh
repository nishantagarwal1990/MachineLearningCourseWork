#!/bin/bash

g++ --std=c++11 svm.cpp -o svm
