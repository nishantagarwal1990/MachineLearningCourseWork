

1>svm.cpp folder contains the source code of SVM.

2> The Nishant-HW4.pdf contains solutions as well as report for the programming assignments.

3> The data provided for assignment is in the data0 and astro folder.


Steps to execute:

1> Open a terminal and enter the directory where the folder is unzipped.

2> Run ./run.sh on the terminal to compile the code.

3> Run ./svm

Note: the executable does not take parameters so the data folder has to be in the same folder as executable.


SVM:

1> The executable has taken the paths as hardcoded for data0 and astro files. So the files in the the format given in the folder specific to the name is used. e.g. train0.10 and test0.10

2> The output is generated in Output.txt file.



