#!/bin/bash

g++ src/main.cpp - o perceptron.out